#!/bin/sh

set -e

./bootstrap.sh
if [ -z "$NOCONFIGURE" ]; then
    exec ./configure --prefix=/usr        \
	       --libdir=/lib/x86_64-linux-gnu "$@"
fi
